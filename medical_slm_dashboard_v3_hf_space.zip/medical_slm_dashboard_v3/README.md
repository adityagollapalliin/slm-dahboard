---
title: Medical-O1 SLM Experiment Dashboard
emoji: 🧠
colorFrom: blue
colorTo: indigo
sdk: gradio
app_file: app.py
pinned: false
license: apache-2.0
---

# Medical-O1 SLM Experiment Dashboard — v3

A Gradio comparison dashboard for multiple Medical-O1 reasoning fine-tuning experiments.

## Included experiments

- Qwen2.5-3B Medical QLoRA
- Phi-4-mini Medical QLoRA — full run
- Phi-4-mini Medical QLoRA — 1K intermediate stage
- DeepSeek-R1-Distill-Qwen-7B Medical QLoRA
- **Qwen2.5-14B Medical LoRA SFT — recovered from the S3 archive**

## New in v3

The Qwen2.5-14B run is now integrated using the forensic recovery outputs:

- 14.77B base parameters
- 19,506 train / 198 validation samples
- 3 completed epochs / 1,830 optimizer steps
- LoRA r=32, alpha=64, dropout=0.05
- effective batch 32
- adamw_8bit + cosine schedule
- BF16 base weights; not QLoRA
- 9.688 h training runtime
- run-mean train loss 1.176091
- final/best eval loss 1.202948
- perplexity 3.32992
- best/exported checkpoint = step 1200
- final training checkpoint = step 1830
- recovered learning curve and checkpoint table
- adapter, merged BF16 and GGUF artifact sizes

GPU model, VRAM, base-model evaluation and accuracy metrics are intentionally left blank because they were not recorded.

## Run locally

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:7860`.

## Data files

- `data/experiments.json`
- `data/repos.json`
- `data/qwen14b_metrics.json`
- `data/qwen14b_training_curve.csv`
- `data/qwen14b_checkpoints.csv`
- `data/qwen14b_forensic_report.md`

## Interpretation

Different model families and runs do not necessarily share tokenizers, evaluation splits, prompts,
masking conventions, or hardware. The dashboard presents recorded metrics with explicit provenance
rather than forcing them into a single leaderboard.

Research artifact only; not clinical validation.
