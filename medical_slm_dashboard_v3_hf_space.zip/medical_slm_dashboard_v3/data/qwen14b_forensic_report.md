# Forensic Report — Qwen2.5-14B × medical-o1-reasoning-SFT (`run-14b`)

*Generated 2026-09-17 from a read-only inspection of `medical-sft-s3-archive-2026/`. No artifact was modified, loaded into a model, or executed. Parsers used only the Python standard library: TFRecord/protobuf for TensorBoard, JSON headers for safetensors, the GGUF v3 header for the GGUF files, and a pickle **opcode scan / no-code-execution unpickler** for `.bin`/`.pt`/`.pth`.*

Confidence tags: **[H]** HIGH = directly recorded in an authoritative artifact · **[M]** MEDIUM = reconstructed from scripts + logs with strong corroboration · **[L]** LOW = indirect / filename-based · **[—]** unknown → `null`.

---

## 1. Executive summary

- **This is a complete, uninterrupted 3-epoch LoRA SFT run** of `Qwen/Qwen2.5-14B-Instruct` on `FreedomIntelligence/medical-o1-reasoning-SFT` (en). It ran 1830/1830 optimizer steps in 34,877.27 s (≈ 9 h 41 m) on one CUDA device. It started fresh ("Starting fresh."), with no resume.
- **It was trained with `train_peft.py` (plain transformers + PEFT), not with the Unsloth scripts.** `run_unsloth.sh`/`train_unsloth.py` are in the folder but disagree with every run artifact.
- **The shipped weights are from step 1200, not step 1830.** `load_best_model_at_end=True` restored the best-eval checkpoint (step 1200, eval_loss 1.2029483318328857) before the final eval and the save. `adapter-14b/`, `run-14b/adapter/` and `run-14b/checkpoint-1200/` hold byte-identical adapters (SHA-256 `29fed4f4…`). `merged_16bit/` and both GGUFs derive from that model.
- **Headline metrics [H]:**
  - train_loss (run mean): 1.1760911430817484
  - final eval_loss: 1.2029483318328857
  - perplexity: 3.3299201736657844
  - 1.678 samples/s
  - total_flos 3.296563477904425e18
- **Not recoverable:** GPU model, VRAM total, peak VRAM, token throughput, Python version, any base-model evaluation, any accuracy metric. No base-vs-adapter comparison is possible.
- **Salvageability: HIGH** for training/eval-loss curves and configuration. **None** for VRAM and base-vs-fine-tuned deltas.

## 2. What the experiment appears to be

| Item | Value | Conf. | Evidence |
|---|---|---|---|
| Base model | `Qwen/Qwen2.5-14B-Instruct` | H | `adapter_config.json` `base_model_name_or_path`; train.log `Loading Qwen/Qwen2.5-14B-Instruct in bf16`; adapter README `base_model:` |
| Architecture | `Qwen2ForCausalLM`, `model_type=qwen2`, 48 layers, hidden 5120, 40 heads / 8 KV heads, vocab 152,064, ctx 32,768 | H | `merged_16bit/config.json` = TensorBoard `model_config/text_summary` |
| Parameter count | 14,770,033,664 (≈14.77 B) base; 14,907,659,264 incl. LoRA | H | `model.safetensors.index.json` metadata + summed shard headers; train.log `print_trainable_parameters` |
| Is it Qwen2.5-14B? | Yes | H | config + param count + log |
| Method | Supervised fine-tuning (SFT) with **LoRA** via **PEFT** and `transformers.Trainer` | H | `training_args.bin` class = `transformers.training_args.TrainingArguments` (not TRL `SFTConfig`); `peft_type: LORA` |
| QLoRA? | **No.** Base loaded in bf16 | H | train.log "in bf16"; `train_peft.py` has no `BitsAndBytesConfig` (`prepare_model_for_kbit_training` is imported but never called) |
| Unsloth? | **No** (installed in the venv, but not used by this run) | H | see §15 |
| Training quantization | None on the weights. **Optimizer states** are 8-bit (bitsandbytes `adamw_8bit`) | H | TB args `optim=adamw_8bit`; `optimizer.pt` contains `__bnb_optimizer_quant_state__`, `state1/state2/absmax/qmap` |
| Dataset | `FreedomIntelligence/medical-o1-reasoning-SFT`, config `en`, split `train` | M | `train_peft.py` defaults; log columns `['Question','Complex_CoT','Response']`; README. The dataset ID itself is never printed in the log |
| Rows loaded / kept | 19,704 / 19,704 (0 % dropped; token length mean 661, p50 641, p95 918, max 1488) | H | train.log |
| Train samples | **19,506** | M | 1 % split (`eval_ratio=0.01`, script default). Confirmed by exact arithmetic: epoch at step 10 = 0.016405208653747564 = 10 / (19506/32) |
| Eval samples | **198** | M | 19,704 − 19,506; eval_samples/s × eval_runtime = 197.99 – 198.01 in every eval |
| Language | English | M | `--dataset_config en` default; English mask-check sample in log |
| Supervision | Assistant tokens only (prompt masked to −100); 577/671 tokens supervised on sample 0 | H | train.log MASK CHECK |
| Frameworks | transformers 4.56.2 [H], peft 0.18.1 [H], torch 2.11.0, bitsandbytes 0.50.2, accelerate 1.14.0, datasets 4.3.0 [M, lock file] | — | §7 |

## 3. Training configuration

Source for all [H] rows: TensorBoard `args/text_summary`, which matches `training_args.bin` (identical SHA-256 in all three checkpoints).

| Parameter | Value | Conf. |
|---|---|---|
| Epochs requested | 3.0 | H |
| Epochs completed | 3.0 | H (`trainer_state.json` `epoch`) |
| Total optimizer steps (`max_steps`) | 1830 (610 per epoch) | H |
| Global step at termination | 1830 | H |
| Final checkpoint | `run-14b/checkpoint-1830` | H |
| Per-device train batch | 1 | H |
| Per-device eval batch | 1 | H |
| Gradient accumulation | 32 | H |
| Effective batch | 32 (1 × 32 × 1 device) | H / M (device count) |
| Max sequence length | 2048 | M — `train_peft.py` default; the run's command line was not preserved. Irrelevant in practice: max example length was 1488 and no rows were dropped |
| Learning rate | 1e-4 | H |
| Scheduler | cosine | H |
| Warmup | `warmup_ratio=0.03`, `warmup_steps=0` → 55 effective steps (ceil(0.03 × 1830)) | H / derived |
| Optimizer | `adamw_8bit` (β1 0.9, β2 0.999, ε 1e-8) | H |
| Weight decay | 0.01 | H |
| max_grad_norm | 1.0 | H |
| Seed | 42 (`data_seed` null) | H |
| Precision | bf16 = true, fp16 = false, tf32 = true | H |
| Gradient checkpointing | true, `use_reentrant=False` | H |
| Packing | none (custom right-padding collator, `pad_to_multiple_of=8`) | M (script) |
| group_by_length | false | H |
| Dataloader workers | 4 | H |
| Logging / eval / save | every 10 / 50 / 50 steps; `save_total_limit=3`; `load_best_model_at_end=True` on `eval_loss` | H |
| Output dir | `/opt/dlami/nvme/out/qwen2.5-14b-medical-o1` (AWS Deep Learning AMI NVMe) | H |

## 4. LoRA / QLoRA configuration

| Field | Value | From `adapter_config.json` | From `train_peft.py` |
|---|---|---|---|
| r | 32 | ✔ | ✔ (default `--lora_r 32`) |
| lora_alpha | 64 | ✔ | ✔ |
| lora_dropout | **0.05** | ✔ | ✔ (Unsloth script would give 0) |
| bias | none | ✔ | ✔ |
| task_type | CAUSAL_LM | ✔ | ✔ |
| target_modules | q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj | ✔ | ✔ |
| modules_to_save | null | ✔ | — |
| use_rslora / use_dora | false / false | ✔ | — |
| peft_version | 0.18.1 | ✔ | — |
| Trainable params | 137,625,600 | adapter header: 672 F32 tensors = 137,625,600 elements | log |
| Total params (PEFT view) | 14,907,659,264 | — | log |
| Trainable % | 0.9232 (log); 0.9231871856… exact | — | log |
| 4-bit config / NF4 / double quant / compute dtype | **None — not QLoRA.** Base in bf16 | n/a | no BnB config in script; log says bf16 |

All five `adapter_config.json` copies are byte-identical.

## 5. Training metrics

**Final (whole-run) metrics** from `final_metrics.json`, confirmed by train.log and TensorBoard `train/*` [H]:

| Metric | Value |
|---|---|
| train_runtime | 34877.2707 s = 581.2878 min = 9.68813 h |
| train_samples_per_second | 1.678 |
| train_steps_per_second | 0.052 |
| total_flos | 3.296563477904425e+18 |
| train_loss (mean over run) | 1.1760911430817484 |
| epoch | 3.0 |
| tokens/s, tokens seen | **null** (`include_tokens_per_second=False`, `num_input_tokens_seen=0`) |
| Wall clock (TB) | 2026-09-07 15:07:21 UTC → 2026-09-08 00:48:39 UTC (consistent with runtime) |

**Loss landmarks** (`trainer_state.json`, logged every 10 steps, 183 points) [H]:

| | Step | Loss |
|---|---|---|
| Initial logged | 10 | 1.5582 (lr 1.6363636363636366e-05, grad_norm 0.692925214767456) |
| Minimum = last logged | 1830 | 1.0663 |
| Mean of logged losses, epoch 1 / 2 / 3 | — | 1.25109 / 1.17201 / 1.10517 *(simple mean of the 61 logged points per epoch; derived)* |

The full per-step series (loss, lr, grad_norm, eval) is in `training_curve.csv`. The learning rate peaks at ~1e-4 after warmup and decays by cosine to 7.83e-11 at step 1830. grad_norm stays in 0.14–0.35 after warmup.

**TensorBoard scalar tags** (event file `…4912.0`, 921 events):
`train/loss` (183), `train/grad_norm` (183), `train/learning_rate` (183), `train/epoch` (220), `eval/loss` (36), `eval/runtime` (36), `eval/samples_per_second` (36), `eval/steps_per_second` (36), `train/train_runtime`, `train/train_samples_per_second`, `train/train_steps_per_second`, `train/total_flos`, `train/train_loss` (1 each). Text tags: `args/text_summary`, `model_config/text_summary`.
The second file (`…4912.1`, 6 events) holds only the final eval at step 1830: `eval/loss`, `eval/runtime`, `eval/samples_per_second`, `eval/steps_per_second`, `train/epoch`.

**Cross-check:** all 183 train and 36 eval entries match exactly across `trainer_state.json`, `train.log` and TensorBoard (TensorBoard within float32 rounding). There are no conflicting rows. The 1200- and 1800-checkpoint `log_history` arrays are exact prefixes of the 1830 one.

## 6. Evaluation metrics

| Eval | Weights evaluated | eval_loss | runtime (s) | samples/s | Source |
|---|---|---|---|---|---|
| Periodic, step 50 | step 50 | 1.278009057044983 | — | — | trainer_state |
| **Best periodic, step 1200** | step 1200 | **1.2029483318328857** | 30.6125 | 6.468 | trainer_state `best_metric` |
| Last periodic, step 1800 | step 1800 | 1.212015986442566 | 30.4958 | 6.493 | trainer_state, log |
| **Final (post-training)** | **step 1200 (best, reloaded)** | **1.2029483318328857** | 29.9892 | 6.602 (steps/s 6.602) | final_metrics.json, log, TB file .1 |
| Perplexity (final) | step 1200 | 3.3299201736657844 = exp(1.2029483318328857) ✔ | — | — | final_metrics.json (written by `train_peft.py`) |

- **Protocol:** held-out token-level cross-entropy on 198 samples (1 % random split, seed 42), assistant tokens only, batch size 1. This is a **validation** split, not a test set, and it is the split used for checkpoint selection. The reported "final" loss is therefore optimistically selected.
- **Trend:** eval loss fell to its minimum at step 1200 (epoch 1.97), rose to 1.2109 at step 1250, and plateaued at 1.211–1.214 through epoch 3 while train loss kept dropping. That pattern suggests mild overfitting in epoch 3.
- **Not present:** base-model eval, eval accuracy, token accuracy, mean token accuracy, entropy, test loss, generation-based or manual medical evaluation. `infer.py` is a smoke-test script with no recorded output (its docstring even references a 1.5B path).
- **Base vs adapter:** **cannot be computed.** `base_eval_loss`, `loss_reduction_*`, `*_token_accuracy` and `token_accuracy_gain_pp` are all `null`.
- **Comparability:** see §17.

## 7. GPU and VRAM

| Field | Value | Evidence |
|---|---|---|
| GPU model | **null** | Not in any log. The only mention is a comment in `run_unsloth.sh` ("single 48GB L40S (g6e.2xlarge)"), and that script was **not** used for this run → not accepted |
| GPU count | **1** [M] | single `rng_state.pth` (not `rng_state_N.pth`) with one `cuda` entry; all 2690 optimizer tensors on `cuda:0`; `local_rank=0`; no distributed backend |
| Total VRAM | **null** | — |
| Peak allocated / reserved VRAM | **null / null** | `skip_memory_metrics=True`; no `nvidia-smi` or `torch.cuda.max_memory_*` output anywhere. The "Peak VRAM ~37GB" comment in `run_unsloth.sh` is a plan for a different script → rejected |
| CUDA | pip wheels `cuda-toolkit==13.0.2`, `nvidia-cuda-runtime==13.0.96` [M, lock file]; driver version unknown | requirements.lock.txt |
| PyTorch | 2.11.0 [M] | lock file |
| Transformers | 4.56.2 [H] | merged `config.json`, TB model_config, lock file |
| TRL | 0.24.0 [M] (installed; **not used** by train_peft.py) | lock file |
| PEFT | 0.18.1 [H] | adapter_config `peft_version`, lock file |
| BitsAndBytes | 0.50.2 [M] | lock file; bnb 8-bit optimizer state confirms bnb was used |
| Unsloth | 2026.9.2 (unsloth_zoo 2026.9.1) [M] (installed; **not used**) | lock file |
| Python | **null** (`bootstrap.sh` creates a `python3.11` venv, but that is a setup script, not a run record) | — |
| Host | AWS EC2 (`ip-172-31-20-208`, `/opt/dlami/nvme` = Deep Learning AMI instance store) | TB run dir name, output_dir |

The lock file is a `pip freeze` with no timestamp, so it cannot be tied to the moment of training beyond agreeing with the two [H] versions.

## 8. Checkpoint analysis

| | checkpoint-1200 | checkpoint-1800 | checkpoint-1830 |
|---|---|---|---|
| global_step / max_steps | 1200 / 1830 | 1800 / 1830 | 1830 / 1830 |
| epoch | 1.9679073105711065 | 2.9515021019173586 | 3.0 |
| train loss at step | 1.1757 | 1.1037 | 1.0663 |
| eval loss at step | **1.2029483318328857 (best)** | 1.212015986442566 | *(no eval at 1830 — never evaluated)* |
| logged LR | 2.807260538562133e-05 | 7.524150496769911e-08 | 7.831463459395671e-11 |
| scheduler.pt `last_epoch` / next LR | 1200 / 2.7993108113107447e-05 | 1800 / 7.046663148979616e-08 | 1830 / 0.0 |
| grad_norm | 0.3528063893318176 | 0.23053357005119324 | 0.29037684202194214 |
| total_flos | 2.1623722402507653e18 | 3.2433582924393185e18 | 3.296563477904425e18 |
| should_training_stop | false | false | **true** |
| adapter_model.safetensors | ✔ 550,593,184 B | ✔ 550,593,184 B | ✔ 550,593,184 B |
| optimizer.pt | ✔ 280,349,285 B | ✔ 280,349,285 B | ✔ 280,349,285 B |
| scheduler.pt | ✔ 1,465 B | ✔ 1,465 B | ✔ 1,465 B |
| rng_state.pth | ✔ 14,645 B | ✔ | ✔ |
| training_args.bin | ✔ 5,905 B (identical in all 3) | ✔ | ✔ |
| trainer_state.json | ✔ | ✔ | ✔ |
| Zip CRC of .pt/.pth/.bin | OK | OK | OK |
| Structurally resumable | Yes | Yes | Yes (resuming would do nothing: run already complete) |
| Adapter SHA-256 prefix | `29fed4f4…` (= exported adapter) | `f4b74ae1…` | `64766499…` |

A resume would also need the base model (not in this folder) plus a matching software stack. The files were checked structurally; nothing was resumed.

**Verdict on checkpoint-1830:** it is **the final checkpoint of a normally completed run**, not an interrupted one. Evidence:
- `global_step == max_steps`, `epoch == 3.0`, `should_training_stop == true`.
- The scheduler reached its end (next LR 0.0).
- The log continues to the training summary, final eval, adapter save and merge (last log line 2026-09-08 00:50:58).

**Why 1200/1800/1830 were kept:** `save_total_limit=3` combined with `load_best_model_at_end` always keeps the best checkpoint (1200) plus the most recent ones. `sync_checkpoints.sh` uses `aws s3 sync --delete`, which mirrors that pruning.

## 9. Final adapter analysis

| | `adapter-14b/` | `run-14b/adapter/` |
|---|---|---|
| Valid PEFT adapter | Yes: `adapter_config.json` + safetensors (672 F32 LoRA tensors, header size consistent with file size) | Yes |
| adapter_model.safetensors | 550,593,184 B (0.5506 GB), SHA-256 `29fed4f4c1e09db9…` | identical |
| adapter_config.json | identical (see §4) | identical |
| Tokenizer artifacts | tokenizer.json, tokenizer_config.json, vocab.json, merges.txt, added_tokens.json, special_tokens_map.json, chat_template.jinja | identical |
| README.md | auto-generated PEFT model card template (empty) | identical |

**The two directories are complete byte-for-byte duplicates** (all 10 files share hashes). Their weights are also identical to `run-14b/checkpoint-1200/adapter_model.safetensors`. **The "final adapter" is the step-1200 best-eval adapter**, which matches `load_best_model_at_end=True`. The step-1830 end-of-training weights exist only in `checkpoint-1830/`.

## 10. Merged model analysis (`run-14b/merged_16bit/`)

- **Shards:** 6 of 6 present: `model-00001…00006-of-00006.safetensors`
  - 4,986,211,280 / 4,954,847,344 / 4,954,847,392 / 4,954,847,392 / 4,954,847,392 / 4,734,533,160 bytes
- **Index:** `model.safetensors.index.json` maps 579 tensors, every one found in the shard it names. There are no extra or missing keys, and every shard header is consistent with its file size.
- **Totals:**
  - index `total_parameters` 14,770,033,664; `total_size` 29,540,067,328 B (tensor bytes)
  - shards on disk 29,540,133,960 B
  - whole directory 29,556,062,464 B (**29.556 GB**, 27.53 GiB)
- **Model:** `model_type=qwen2`, `Qwen2ForCausalLM`, `dtype=bfloat16` (all 579 tensors BF16), 48 layers (0–47), separate `lm_head.weight`. No `lora_` keys, so the adapter is fully merged.
- **Generation config:** `generation_config.json` has temperature 0.7, top_p 0.8, top_k 20, repetition_penalty 1.05. The tokenizer files are identical to the adapter copies.
- **Structurally complete: yes.** Its parameter count equals the PEFT total minus the LoRA params, exactly.
- **Provenance [M]:** `train_peft.py` merges the in-memory model after `load_best_model_at_end`, so this is base + **checkpoint-1200** adapter. Verifying that numerically would require the base weights, which are not in the folder.

## 11. GGUF / export analysis (`release/`)

| File | Quant (GGUF `general.file_type`) | Tensor types | Size | SHA-256 prefix |
|---|---|---|---|---|
| `qwen2.5-14b-medical-o1-Q4_K_M.gguf` | **Q4_K_M** (15) | Q4_K ×289, Q6_K ×49, F32 ×241 | 8,988,110,240 B (8.988 GB) | `90a8018b…` |
| `qwen2.5-14b-medical-o1-Q8_0.gguf` | **Q8_0** (7) | Q8_0 ×338, F32 ×241 | 15,701,597,600 B (15.702 GB) | `9dd7b1b2…` |

- Both are GGUF v3, `general.architecture=qwen2`, 48 blocks, 579 tensors, 14,770,033,664 params.
- `general.name = "Merged_16Bit"`: `convert_hf_to_gguf.py` derives this name from the `merged_16bit` directory.
- The embedded sampling defaults (top_k 20, top_p 0.8, temp 0.7, repeat 1.05) equal `merged_16bit/generation_config.json`.
- → **These are exports of this run's merged model [M].** They are deployment artifacts, **not separate experiments**.
- `release/Modelfile` (= root `Modelfile`) targets Q8_0 with the training system prompt, ChatML, temp 0.6 and num_ctx 8192. `release/README.md` (= `TEACHER_README.md`) is an end-user guide.
- The GGUF-embedded chat template is the stock Qwen2.5 template (default system prompt "You are Qwen…"). Only the Modelfile supplies the fine-tuning system prompt. Other runtimes (LM Studio, llama-server) will not use it unless configured to.
- The f16 intermediate GGUF made by `export_gguf.sh` is not present, as the script instructs.

## 12. Duplicate artifact analysis

| Hash group | Files | Interpretation |
|---|---|---|
| `29fed4f4…` (550.6 MB ×3) | `adapter-14b/`, `run-14b/adapter/`, `run-14b/checkpoint-1200/` adapter_model.safetensors | **Same adapter three times**: final exported adapter = best checkpoint |
| all other adapter-14b ↔ run-14b/adapter files | config, tokenizer, template, README | `adapter-14b/` is a verbatim copy of `run-14b/adapter/` |
| tokenizer files ×3 | adapter-14b, run-14b/adapter, merged_16bit | same tokenizer saved with each artifact |
| `adapter_config.json` ×5, `README.md` ×5, `training_args.bin` ×3 | adapters + checkpoints | identical config across the run |
| `final_metrics.json` ×2 | root, run-14b/ | copy |
| `Modelfile` ×2, `TEACHER_README.md` = `release/README.md` | root, release/ | copies of deployment docs |

**Artifact roles:**
- Intermediate checkpoints: `checkpoint-1800` and `checkpoint-1830`. The 1830 one is the true final-step state, but it was never exported.
- Final adapter: `run-14b/adapter/`, duplicated as `adapter-14b/`, = step 1200.
- Merged model: `run-14b/merged_16bit/`.
- Quantized deployment exports: `release/*.gguf`.

Removing the duplicates would reclaim ≈ 1.10 GB. **Nothing was removed.**

## 13. Metric provenance

| Metric | Value | Primary source | Corroboration | Conf. |
|---|---|---|---|---|
| train_runtime | 34877.2707 | final_metrics.json | train.log, TB `train/train_runtime` (34877.26953125, float32) | H |
| train_samples_per_second | 1.678 | final_metrics.json | log, TB | H |
| train_steps_per_second | 0.052 | final_metrics.json | log, TB | H |
| total_flos | 3.296563477904425e+18 | final_metrics.json | ckpt-1830 trainer_state, TB | H |
| train_loss (mean) | 1.1760911430817484 | final_metrics.json | log, TB | H |
| final eval_loss | 1.2029483318328857 | final_metrics.json | log, TB file .1, = step-1200 eval | H |
| eval_runtime | 29.9892 | final_metrics.json | log, TB | H |
| perplexity | 3.3299201736657844 | final_metrics.json | exp(eval_loss) ✔ | H |
| Loss / LR / grad-norm curve | 183 points | ckpt-1830 trainer_state.json | log (exact), TB (float32) | H |
| Eval curve | 36 points | ckpt-1830 trainer_state.json | log, TB | H |
| Hyperparameters | §3 | TB args text | training_args.bin | H |
| LoRA config | §4 | adapter_config.json | train_peft.py | H |
| Trainable / total params | 137,625,600 / 14,907,659,264 | train.log | safetensors headers, index | H |
| Train / eval samples | 19,506 / 198 | derived | log row count, epoch arithmetic, throughput × runtime | M |
| max_seq_length | 2048 | train_peft.py default | no row dropped at max 1488 | M |
| GPU count | 1 | rng_state / optimizer device | TB `local_rank=0` | M |
| Framework versions (non-transformers/peft) | §7 | requirements.lock.txt | — | M |

## 14. Missing metrics (reported as `null`)

- GPU model, GPU VRAM total, peak VRAM allocated/reserved, CUDA driver version
- Python version
- tokens/second, tokens processed (`num_input_tokens_seen=0`)
- Base-model eval loss, and therefore all base-vs-adapter deltas
- eval accuracy, token accuracy, mean token accuracy, entropy
- test-set metrics, generation-based or manual medical evaluation results
- Eval loss of the step-1830 weights (never evaluated)
- The exact command line used to launch `train_peft.py`

## 15. Conflicts / inconsistencies

1. **Which script ran.**

   | Aspect | `run_unsloth.sh` + `train_unsloth.py` | Recorded evidence | Verdict |
   |---|---|---|---|
   | Base | `unsloth/Qwen2.5-14B-Instruct` | `Qwen/Qwen2.5-14B-Instruct` (adapter_config, log) | PEFT script |
   | Batch × accum | 2 × 16 | **1 × 32** (TB args, training_args.bin, trainer_state `train_batch_size: 1`) | PEFT script |
   | lora_dropout | 0 | **0.05** (adapter_config) | PEFT script |
   | Config class | TRL `SFTConfig` | `transformers.TrainingArguments` (training_args.bin) | PEFT script |
   | final_metrics `perplexity` key | not written | present | PEFT script |
   | Log format | "Keeping N/M rows … dropped as over-length"; "This TRL version uses …" | "Kept 19704/19704 rows … Tokens: mean=…"; "Starting fresh." | PEFT script |
   | Grad checkpointing | `"unsloth"` | `True`, `use_reentrant=False` (TB args) | PEFT script |

   → Treat **every Unsloth-script value as not applicable** to this run, including its "L40S 48GB / peak ~37GB" comment.
2. **"Final" eval vs final weights.** final_metrics.json labels eval_loss 1.2029483318328857 with `epoch: 3.0`, but it is the step-1200 model. The step-1800 eval was 1.212015986442566, and the step-1830 weights were never evaluated. Both values are shown above with their sources.
3. **"Final train loss" ambiguity.** `train_loss` = 1.1760911430817484 (run mean, final_metrics.json) vs last logged step loss = 1.0663 (trainer_state.json step 1830). The two measure different things.
4. **Log-rate display artifact.** In train.log, eval dicts are printed on the same line as a stale tqdm bar (e.g. "100/1830 … {'eval_loss': 1.278…, 'epoch': 0.08}"). The value belongs to step 50 per trainer_state and epoch arithmetic. This is a display artifact, not a data conflict.
5. **Scheduler LR vs logged LR.** Example at step 1200: scheduler.pt `_last_lr` = 2.7993108113107447e-05 vs logged `learning_rate` = 2.807260538562133e-05. These are different quantities (LR for the *next* step vs LR at log time), not a data conflict.
6. **peft pin.** `fix_env.sh` pins `peft<0.18`, but `requirements.lock.txt` has `peft==0.18.1`, and the adapter was written by peft 0.18.1. The lock file and the artifact agree; fix_env.sh's pin was evidently not what was installed at save time.
7. **Dataset description.** `TEACHER_README.md` says the data is "~19,700 exam-style questions derived from MedQA and MedMCQA". The row count agrees (19,704 loaded, 19,506 trained). The MedQA/MedMCQA origin is not verifiable from this folder.
8. **Adapter size comment.** `train_unsloth.py` says "~200MB LoRA adapter"; the actual size is 550,593,184 B.
9. **Archive inventory.** `file_inventory.txt` omits both TensorBoard event files under `run-14b/runs/`.
10. **Precision.** TensorBoard stores float32 (e.g. train_loss 1.176091194152832). The float64 values in final_metrics.json / trainer_state.json were used everywhere.

## 16. What can safely be used in the comparison dashboard

HIGH-confidence values from `comparison_metrics_14b.json`:
- **Identity and method:** base model, parameter count, method (LoRA/PEFT, bf16, not QLoRA), LoRA r/alpha/dropout/targets, trainable params and %.
- **Hyperparameters:** epochs, steps, LR, scheduler, warmup ratio, optimizer, weight decay, batch 1 × 32 = 32, seed, precision.
- **Throughput:** training runtime (s/min/h), samples/s, steps/s, total FLOPs.
- **Losses:** train_loss (labelled "mean over run"), final/best eval loss 1.2029483318328857 and perplexity 3.3299 (labelled "best checkpoint, step 1200, 198-sample val split").
- **Curves:** the full train/eval curve (`training_curve.csv`).
- **Artifact sizes:** adapter 0.5506 GB, merged 29.556 GB, GGUF sizes and quant types.
- **With a MEDIUM badge:** train/eval sample counts (19,506 / 198), max_seq_length 2048, GPU count 1.

## 17. What should NOT be compared directly

- **Peak VRAM / GPU:** unknown for this run. Do not fill in from run_unsloth.sh comments or from another experiment.
- **Base-vs-fine-tuned improvement:** not measured. Leave null; do not borrow a base loss from another model.
- **eval_loss / perplexity across tokenizers:** Phi-4-mini uses a different tokenizer, so per-token loss is not like-for-like. Even Qwen-family models (Qwen2.5-3B, R1-Distill-Qwen-7B) are only comparable if their 198-row split, masking, system prompt and length filter were identical. Verify that in their folders before comparing.
- **Runtime / throughput:** they depend on hardware (unknown here), batch shape (1 × 32 with gradient checkpointing) and the non-Unsloth stack. Other runs that used Unsloth or different GPUs are not directly comparable.
- **"Final train loss":** make sure every model reports the same definition (run mean vs last step).
- **"Final eval loss":** here it is the *best* checkpoint's loss, selected on the same split. Compare only with models that report the same (best-checkpoint) quantity.
- **GGUF files:** deployment exports, not additional experiments.

## 18. Overall salvageability assessment

**HIGH (≈ 85 %) for training/eval-loss analytics.** The folder has three mutually consistent authoritative sources (trainer_state, TensorBoard, train.log) plus final_metrics.json, full training args, the adapter config, and a structurally complete, resumable set of checkpoints. The merged model and both GGUF exports are intact and traceable to this run.

**Unrecoverable:** hardware/VRAM metrics, base-model baseline, and any accuracy-style or clinical evaluation. Those would require new evaluation runs, which were out of scope here and were not performed.

The most important caveat for the dashboard: **all shipped weights are the step-1200 best checkpoint, not the end-of-epoch-3 model.**
