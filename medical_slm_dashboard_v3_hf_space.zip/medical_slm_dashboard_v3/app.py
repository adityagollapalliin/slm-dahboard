import json
from pathlib import Path

import gradio as gr
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

ROOT = Path(__file__).parent
EXP = pd.DataFrame(json.loads((ROOT / "data" / "experiments.json").read_text()))
REPOS = pd.DataFrame(json.loads((ROOT / "data" / "repos.json").read_text()))
Q14 = json.loads((ROOT / "data" / "qwen14b_metrics.json").read_text())
Q14_CURVE = pd.read_csv(ROOT / "data" / "qwen14b_training_curve.csv")
Q14_CKPTS = pd.read_csv(ROOT / "data" / "qwen14b_checkpoints.csv")

def only_final(df):
    return df[df["status"] == "Final adapter"].copy()

def value(r, key, default=None):
    v = r.get(key, default)
    if v is None:
        return default
    try:
        if pd.isna(v):
            return default
    except Exception:
        pass
    return v

def display_num(v, digits=2, suffix=""):
    if v is None:
        return "—"
    try:
        if pd.isna(v):
            return "—"
    except Exception:
        pass
    return f"{float(v):.{digits}f}{suffix}"

def display_int(v):
    if v is None:
        return "—"
    try:
        if pd.isna(v):
            return "—"
    except Exception:
        pass
    return f"{int(float(v)):,}"

def repo_link(repo):
    if repo is None:
        return "Not linked / local recovery"
    try:
        if pd.isna(repo):
            return "Not linked / local recovery"
    except Exception:
        pass
    if not repo:
        return "Not linked / local recovery"
    return f"[{repo}](https://huggingface.co/{repo})"

def cards():
    finals = only_final(EXP)
    public_repos = len(REPOS)
    artifacts = int(REPOS["classification"].str.contains("artifact", case=False).sum())
    recovered = int(finals["metric_source"].astype(str).str.contains("recover", case=False).sum())
    return f"""
    <div class="cards">
      <div class="card"><div class="k">Final training experiments</div><div class="v">{len(finals)}</div></div>
      <div class="card"><div class="k">Public repos identified</div><div class="v">{public_repos}</div></div>
      <div class="card"><div class="k">Export / artifact repos</div><div class="v">{artifacts}</div></div>
      <div class="card"><div class="k">Runs with recovered local metrics</div><div class="v">{recovered}</div></div>
    </div>
    """

def paired_loss_chart():
    d = EXP.dropna(subset=["paired_base_eval_loss", "paired_adapter_eval_loss"]).copy()
    if d.empty:
        return go.Figure().update_layout(title="No paired evaluation-loss results recovered")
    long = d.melt(
        id_vars=["model", "status"],
        value_vars=["paired_base_eval_loss", "paired_adapter_eval_loss"],
        var_name="stage", value_name="eval_loss"
    )
    long["stage"] = long["stage"].map({
        "paired_base_eval_loss": "Base",
        "paired_adapter_eval_loss": "Fine-tuned"
    })
    fig = px.bar(
        long, x="model", y="eval_loss", color="stage", barmode="group",
        text_auto=".3f",
        labels={"model":"", "eval_loss":"Held-out evaluation loss", "stage":""}
    )
    fig.update_layout(title="Paired Base vs Adapter Evaluation Loss")
    return fig

def final_eval_chart():
    d = only_final(EXP).dropna(subset=["final_eval_loss"]).copy()
    if d.empty:
        return go.Figure().update_layout(title="No final evaluation losses recovered")
    fig = px.bar(
        d, x="model", y="final_eval_loss", text_auto=".4f",
        labels={"model":"", "final_eval_loss":"Reported final/best eval loss"}
    )
    fig.update_layout(title="Reported Final / Best Evaluation Loss")
    return fig

def token_chart():
    d = EXP.dropna(subset=["paired_base_token_accuracy", "paired_adapter_token_accuracy"]).copy()
    if d.empty:
        return go.Figure().update_layout(title="No paired token-accuracy metrics recovered")
    long = d.melt(
        id_vars=["model"],
        value_vars=["paired_base_token_accuracy", "paired_adapter_token_accuracy"],
        var_name="stage", value_name="acc"
    )
    long["stage"] = long["stage"].map({
        "paired_base_token_accuracy":"Base",
        "paired_adapter_token_accuracy":"Fine-tuned"
    })
    long["pct"] = long["acc"] * 100
    fig = px.bar(
        long, x="model", y="pct", color="stage", barmode="group",
        text_auto=".2f",
        labels={"model":"", "pct":"Mean token accuracy (%)", "stage":""}
    )
    fig.update_layout(title="Paired Token Accuracy")
    return fig

def manual_chart():
    d = EXP.dropna(subset=["base_manual_accuracy", "adapter_manual_accuracy"]).copy()
    if d.empty:
        return go.Figure().update_layout(title="No manual-correctness result recovered")
    long = d.melt(
        id_vars=["model"],
        value_vars=["base_manual_accuracy", "adapter_manual_accuracy"],
        var_name="stage", value_name="acc"
    )
    long["stage"] = long["stage"].map({
        "base_manual_accuracy":"Base",
        "adapter_manual_accuracy":"Fine-tuned"
    })
    long["pct"] = long["acc"] * 100
    fig = px.bar(
        long, x="model", y="pct", color="stage", barmode="group",
        text_auto=".1f",
        labels={"model":"", "pct":"Manual correctness (%)", "stage":""}
    )
    fig.update_layout(title="Manual Held-out Correctness — Separate Protocol")
    return fig

def runtime_chart():
    d = only_final(EXP).dropna(subset=["training_minutes"]).copy()
    d["hours"] = d["training_minutes"] / 60
    fig = px.bar(
        d, x="model", y="hours", text_auto=".2f",
        labels={"model":"", "hours":"Training wall-clock (hours)"}
    )
    fig.update_layout(title="Final-run Training Time")
    return fig

def vram_chart():
    d = only_final(EXP).copy()
    d["peak_vram"] = d["peak_vram_allocated_gb"].combine_first(d["peak_vram_reserved_gb"])
    d = d.dropna(subset=["peak_vram"])
    if d.empty:
        return go.Figure().update_layout(title="No peak-VRAM data recovered")
    fig = px.bar(
        d, x="model", y="peak_vram", text_auto=".2f",
        labels={"model":"", "peak_vram":"Peak VRAM captured (GB)"}
    )
    fig.update_layout(title="Peak Training VRAM — Captured Runs Only")
    return fig

def model_scale_chart():
    d = only_final(EXP).dropna(subset=["parameters_b", "training_minutes"]).copy()
    d["training_hours"] = d["training_minutes"] / 60
    fig = px.scatter(
        d,
        x="parameters_b",
        y="training_hours",
        size="train_samples",
        hover_name="model",
        hover_data=["method", "gpu", "train_samples", "epochs"],
        labels={"parameters_b":"Model parameters (B)", "training_hours":"Training time (hours)"}
    )
    fig.update_layout(title="Model Scale vs Training Wall-clock")
    return fig

def experiment_table():
    wanted = [
        "model","status","method","parameters_b","train_samples","eval_samples","epochs",
        "effective_batch","learning_rate","lora_rank","lora_alpha",
        "gpu","training_minutes","peak_vram_allocated_gb","peak_vram_reserved_gb",
        "final_train_loss","last_step_train_loss","final_eval_loss","final_eval_perplexity",
        "best_checkpoint_step","metric_source"
    ]
    d = EXP.reindex(columns=wanted).copy()
    d.columns = [
        "Model","Stage","Method","Params (B)","Train samples","Eval samples","Epochs",
        "Effective batch","LR","LoRA r","LoRA α",
        "GPU","Training min","Peak alloc GB","Peak reserved GB",
        "Train loss (run mean)","Last step loss","Final/best eval loss","Perplexity",
        "Best ckpt step","Metric source"
    ]
    return d

def repo_table():
    d = REPOS.copy()
    cols = [
        "repo","classification","family","parent_experiment","format","downloads",
        "updated","dashboard_role","notes"
    ]
    out = d[cols].copy()
    out.columns = [
        "Repository","Classification","Family","Parent experiment","Format",
        "Downloads","Updated","Dashboard role","Notes"
    ]
    return out

def coverage_table():
    fields = [
        ("HF repo","hf_repo"),
        ("Train loss","final_train_loss"),
        ("Eval loss","final_eval_loss"),
        ("Paired base/adapt loss","paired_base_eval_loss"),
        ("Paired token accuracy","paired_base_token_accuracy"),
        ("GPU","gpu"),
        ("Peak VRAM","peak_vram_reserved_gb"),
        ("Training time","training_minutes")
    ]
    rows = []
    for _, r in only_final(EXP).iterrows():
        row = {"Model": r["model"]}
        for label, key in fields:
            if key == "peak_vram_reserved_gb":
                ok = pd.notna(r.get("peak_vram_reserved_gb")) or pd.notna(r.get("peak_vram_allocated_gb"))
            else:
                v = r.get(key)
                ok = v is not None and not (isinstance(v, float) and pd.isna(v))
                if isinstance(v, str):
                    ok = bool(v.strip())
            row[label] = "✓" if ok else "—"
        rows.append(row)
    return pd.DataFrame(rows)

def q14_learning_curve():
    d = Q14_CURVE.copy()
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=d["step"], y=d["train_loss"], mode="lines",
        name="Train loss"
    ))
    eval_d = d.dropna(subset=["eval_loss"])
    fig.add_trace(go.Scatter(
        x=eval_d["step"], y=eval_d["eval_loss"], mode="lines+markers",
        name="Eval loss"
    ))
    fig.add_vline(
        x=Q14["best_eval_step"],
        line_dash="dash",
        annotation_text=f"Best/exported checkpoint: {Q14['best_eval_step']}",
        annotation_position="top"
    )
    fig.add_vline(
        x=Q14["global_step"],
        line_dash="dot",
        annotation_text=f"Training completed: {Q14['global_step']}",
        annotation_position="bottom"
    )
    fig.update_layout(
        title="Qwen2.5-14B Learning Dynamics",
        xaxis_title="Optimizer step",
        yaxis_title="Loss",
        legend_title_text=""
    )
    return fig

def q14_lr_curve():
    d = Q14_CURVE.copy()
    fig = px.line(
        d, x="step", y="learning_rate",
        labels={"step":"Optimizer step", "learning_rate":"Learning rate"}
    )
    fig.update_layout(title="Qwen2.5-14B Learning-rate Schedule")
    return fig

def q14_checkpoint_table():
    cols = [
        "checkpoint","global_step","epoch","train_loss_at_step","eval_loss_at_step",
        "learning_rate_logged","grad_norm","should_training_stop",
        "resumable_structurally","identical_to_exported_adapter","role"
    ]
    out = Q14_CKPTS[cols].copy()
    out.columns = [
        "Checkpoint","Step","Epoch","Train loss","Eval loss",
        "Logged LR","Grad norm","Training stop","Structurally resumable",
        "Same as exported adapter","Role"
    ]
    return out

def q14_artifact_chart():
    rows = [
        {"Artifact":"LoRA adapter", "Size GB":Q14["adapter_size_gb"]},
        {"Artifact":"Merged BF16 model", "Size GB":Q14["merged_model_size_gb"]},
    ]
    for a in Q14.get("gguf_artifacts", []):
        rows.append({
            "Artifact":a.get("quantization", a.get("file", "GGUF")),
            "Size GB":a.get("size_gb")
        })
    d = pd.DataFrame(rows)
    fig = px.bar(d, x="Artifact", y="Size GB", text_auto=".2f")
    fig.update_layout(title="Qwen2.5-14B Recovered Artifact Sizes")
    return fig

def q14_summary():
    return f"""
### Qwen2.5-14B recovered run

**Base model:** `{Q14['base_model']}`  
**Method:** LoRA SFT with Transformers + PEFT in BF16; **not QLoRA and not the Unsloth script**  
**Scale:** {Q14['parameters_b']:.2f}B base parameters · {Q14['trainable_parameters']:,} trainable LoRA parameters ({Q14['trainable_percentage']:.4f}%)  
**Data:** {Q14['train_samples']:,} train / {Q14['eval_samples']:,} validation samples  
**Training:** {Q14['epochs_completed']:.0f} epochs · {Q14['global_step']:,} steps · effective batch {Q14['effective_batch_size']} · LR {Q14['learning_rate']:.1e} · `{Q14['optimizer']}`  
**Runtime:** {Q14['training_runtime_hours']:.3f} h · {Q14['samples_per_second']:.3f} samples/s · {Q14['steps_per_second']:.3f} steps/s  
**Train loss:** {Q14['final_train_loss']:.6f} run mean · {Q14['last_logged_step_train_loss']:.4f} at final logged step  
**Best/final exported eval loss:** {Q14['final_eval_loss']:.6f} · perplexity {Q14['final_eval_perplexity']:.4f}  
**Best/exported checkpoint:** step **{Q14['best_eval_step']}**  
**Training completed at:** step **{Q14['global_step']}**  
**GPU / peak VRAM:** not recorded  
**Base-model baseline / accuracy:** not recorded, so no improvement percentage is shown  

> `load_best_model_at_end=True` restored checkpoint {Q14['best_eval_step']} before the final save. The exported adapter, merged BF16 model, and GGUFs therefore represent the best checkpoint, not the final step-{Q14['global_step']} weights.
"""

def detail(model):
    r = EXP[EXP["model"] == model].iloc[0]
    paired_loss = "—"
    if pd.notna(r.get("paired_base_eval_loss")) and pd.notna(r.get("paired_adapter_eval_loss")):
        paired_loss = (
            f'{r["paired_base_eval_loss"]:.6f} → {r["paired_adapter_eval_loss"]:.6f}'
            + (
                f' ({r["paired_loss_reduction_pct"]:.2f}% reduction)'
                if pd.notna(r.get("paired_loss_reduction_pct")) else ""
            )
        )
    tok = "—"
    if pd.notna(r.get("paired_base_token_accuracy")) and pd.notna(r.get("paired_adapter_token_accuracy")):
        tok = f'{r["paired_base_token_accuracy"]*100:.2f}% → {r["paired_adapter_token_accuracy"]*100:.2f}%'
    manual = "—"
    if pd.notna(r.get("base_manual_accuracy")) and pd.notna(r.get("adapter_manual_accuracy")):
        manual = f'{r["base_manual_accuracy"]*100:.1f}% → {r["adapter_manual_accuracy"]*100:.1f}%'

    extra = ""
    if model == "Qwen2.5-14B-Instruct":
        extra = f"""
**Optimizer / precision:** `{value(r, "optimizer", "—")}` · {value(r, "precision", "—")}  
**Best checkpoint:** step {display_int(value(r, "best_checkpoint_step"))}  
**Training final checkpoint:** step {display_int(value(r, "final_checkpoint_step"))}  
**Exported checkpoint:** step {display_int(value(r, "exported_checkpoint_step"))}  
**Perplexity:** {display_num(value(r, "final_eval_perplexity"), 4)}  
**Trainable %:** {display_num(value(r, "trainable_percentage"), 4)}%  
**Adapter / merged model:** {display_num(value(r, "adapter_size_gb"), 3)} GB / {display_num(value(r, "merged_model_size_gb"), 3)} GB  
"""

    return f"""
### {r['model']}
**Experiment:** {r['experiment']}  
**Stage:** {r['status']}  
**Base model:** `{r['base_model']}`  
**Hub repo:** {repo_link(r.get('hf_repo'))}  
**Dataset:** `{r['dataset']}`  
**Method:** {r['method']}  
**Training set:** {display_int(r.get('train_samples'))} samples  
**Evaluation set:** {display_int(r.get('eval_samples'))} samples  
**GPU:** {value(r, 'gpu', '—') or '—'}  
**Training time:** {display_num(r.get('training_minutes'))} min  
**Peak allocated VRAM:** {display_num(r.get('peak_vram_allocated_gb'))} GB  
**Peak reserved VRAM:** {display_num(r.get('peak_vram_reserved_gb'))} GB  
**Final train loss:** {display_num(r.get('final_train_loss'), 6)}  
**Final eval/validation loss:** {display_num(r.get('final_eval_loss'), 6)}  
**Paired base → adapter loss:** {paired_loss}  
**Paired token accuracy:** {tok}  
**Manual correctness:** {manual}  
{extra}
**Evaluation protocol:** {r['evaluation_type']}  
**Metric source:** {r['metric_source']}  

> {r['notes']}
"""

CSS = """
.gradio-container {max-width: 1450px !important;}
.hero {padding: 16px 2px 8px;}
.hero h1 {font-size:2.15rem; margin-bottom:.3rem;}
.sub {opacity:.74;}
.cards {display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin:14px 0 20px;}
.card {border:1px solid rgba(128,128,128,.22); border-radius:14px; padding:16px 18px; background:rgba(128,128,128,.05);}
.k {font-size:.82rem; opacity:.67; margin-bottom:5px;}
.v {font-size:1.55rem; font-weight:700;}
@media(max-width:850px){.cards{grid-template-columns:repeat(2,1fr);}}
"""

with gr.Blocks(css=CSS, title="Medical-O1 SLM Experiment Dashboard") as demo:
    gr.HTML("""
    <div class="hero">
      <h1>Medical-O1 SLM Experiment Dashboard</h1>
      <div class="sub">Fine-tuning experiments, evaluation behavior, hardware footprint, learning dynamics, and Hugging Face artifact lineage</div>
    </div>
    """)
    gr.HTML(cards())

    with gr.Tabs():
        with gr.Tab("Executive comparison"):
            with gr.Row():
                gr.Plot(paired_loss_chart())
                gr.Plot(final_eval_chart())
            with gr.Row():
                gr.Plot(runtime_chart())
                gr.Plot(vram_chart())
            with gr.Row():
                gr.Plot(model_scale_chart())
                gr.Plot(token_chart())
            gr.Plot(manual_chart())
            gr.Markdown("""
**Comparability warning:** these experiments do not all share the same tokenizer, held-out split, masking, evaluation protocol, or hardware.
The charts expose the recorded metrics but do not imply that every bar is directly comparable. In particular, the 14B eval loss is the
best checkpoint selected on its own 198-sample validation split, and it has no base-model baseline.
""")

        with gr.Tab("Experiments"):
            gr.Dataframe(experiment_table(), interactive=False, wrap=True)
            gr.Markdown("### Metric coverage")
            gr.Dataframe(coverage_table(), interactive=False, wrap=True)

        with gr.Tab("Qwen2.5-14B recovery"):
            gr.Markdown(q14_summary())
            with gr.Row():
                gr.Plot(q14_learning_curve())
                gr.Plot(q14_lr_curve())
            gr.Markdown("### Checkpoints")
            gr.Dataframe(q14_checkpoint_table(), interactive=False, wrap=True)
            gr.Plot(q14_artifact_chart())
            gr.Markdown("""
**Interpretation:** checkpoint 1830 is the final state of a normally completed three-epoch run.
Checkpoint 1200 had the lowest validation loss and was reloaded by `load_best_model_at_end`;
it is byte-identical to the exported adapter. The merged model and GGUFs are therefore deployment
artifacts of the step-1200 best checkpoint.
""")

        with gr.Tab("Repository inventory"):
            gr.Markdown("""
This tab separates **training experiments** from **deployment/export artifacts** so GGUF or merged copies
are not double-counted as independent training runs.
""")
            gr.Dataframe(repo_table(), interactive=False, wrap=True)

        with gr.Tab("Model behavior"):
            selector = gr.Dropdown(
                choices=EXP["model"].tolist(),
                value=EXP["model"].tolist()[0],
                label="Choose experiment"
            )
            md = gr.Markdown(detail(EXP["model"].tolist()[0]))
            selector.change(detail, inputs=selector, outputs=md)

        with gr.Tab("Data quality & provenance"):
            gr.Markdown("""
### Qwen2.5-14B forensic provenance

The recovered 14B metrics are based on mutually corroborating `final_metrics.json`,
`trainer_state.json`, TensorBoard events, `train.log`, PEFT adapter configuration, safetensors
headers, checkpoint state, and GGUF metadata.

**Known missing fields for the 14B run:** GPU model, total/peak VRAM, base-model evaluation,
accuracy/token-accuracy metrics, tokens/s, and the exact launch command. These remain blank.

**Key distinction:** the run completed at step 1830, but `load_best_model_at_end=True` selected
step 1200. The exported adapter, merged BF16 model, Q4_K_M GGUF and Q8_0 GGUF all trace to
the step-1200 best checkpoint.

### Cross-model guardrails

- Per-token loss/perplexity should not be treated as strictly comparable across different tokenizers.
- Runtime depends on hardware, training stack, sequence length, gradient checkpointing and batch shape.
- Missing GPU/VRAM values are never estimated.
- Base-vs-adapter deltas are only shown where both measurements actually exist.
- This dashboard is research evidence, not clinical validation.
""")

        with gr.Tab("Raw data"):
            gr.Markdown("#### experiments.json")
            gr.JSON(value=json.loads((ROOT / "data" / "experiments.json").read_text()))
            gr.Markdown("#### Qwen2.5-14B forensic metrics")
            gr.JSON(value=Q14)

if __name__ == "__main__":
    demo.launch()
